from flask import Flask, render_template, request, jsonify
from apscheduler.schedulers.background import BackgroundScheduler
import pyodbc
import requests
from datetime import datetime, timedelta
from app3 import get_condition_icon  # Make sure this function exists

app = Flask(__name__)
app.secret_key = "secret"

# API keys and DB info
VC_API_KEYS = [
    'JFSSVCVP2PZV6FL2HRPLMADAT',
    'DSR5VPHEX7JAARV7BET5TST9T',
    '9QE7RYKNFAR488VSFEP7MRZDG',
    'P8VTN4UHMDAMQHTFF9XMLQNMC',
    '2ECCLNJ89FMCU53G6VWLQCU5Q'
]
CURRENT_API_KEY_INDEX = 0
DB_SERVER = '172.18.25.38'
DB_USER = 'sa'
DB_PASSWORD = 'wwilscada@4444'
DB_NAME = 'Weatherforecast'

# DB connection
def get_db_connection():
    conn = pyodbc.connect(
        f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={DB_SERVER};DATABASE={DB_NAME};UID={DB_USER};PWD={DB_PASSWORD}"
    )
    conn.autocommit = True
    return conn

def rotate_api_key():
    global CURRENT_API_KEY_INDEX
    CURRENT_API_KEY_INDEX = (CURRENT_API_KEY_INDEX + 1) % len(VC_API_KEYS)

def convert_wind_direction(degrees):
    try:
        directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
        idx = round(float(degrees) / 45) % 8
        return directions[idx]
    except:
        return 'Unknown'

def get_weather_data(lat, lon):
    global CURRENT_API_KEY_INDEX
    today = datetime.now().date()
    end_date = today + timedelta(days=4)
    last_exception = None

    for _ in range(len(VC_API_KEYS)):
        current_key = VC_API_KEYS[CURRENT_API_KEY_INDEX]
        url = f"https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/{lat},{lon}/{today}/{end_date}?unitGroup=metric&key={current_key}"
        try:
            print(f"🌐 Trying key: {current_key}")
            response = requests.get(url, timeout=20)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"⛔ Key failed: {current_key} -- {e}")
            last_exception = e
            rotate_api_key()

    raise Exception(f"❌ All API keys failed. Last error: {last_exception}")

@app.route("/", methods=["GET"])
def home():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT State FROM [dbo].[WEC_All_Data_2] WHERE State IS NOT NULL AND State != ''")
        states = [row[0] for row in cursor.fetchall()]
        return render_template("index.html", states=states)
    except Exception as e:
        return f"<h2>Error loading states: {e}</h2>"
    finally:
        conn.close()

@app.route("/dashboard", methods=["GET"])
def dashboard():
    server_time = datetime.now().strftime("%H:%M:%S")
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT TOP 5 * FROM [dbo].[WeatherData2]
            WHERE ForecastDate >= CAST(GETDATE() AS DATE)
            ORDER BY Createdon ASC
        """)
        records = [dict(zip([column[0] for column in cursor.description], row)) for row in cursor.fetchall()]
        return render_template('dashboard.html', server_time=server_time, weather_data=records)
    except Exception as e:
        return f"<h2>Error loading dashboard data: {e}</h2>"
    finally:
        conn.close()

@app.route('/get_forecast', methods=['GET'])
def get_forecast():
    locno = request.args.get('locno')
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT TOP 5 
            FORMAT(CreatedOn, 'ddd') AS Day,
            ROUND(Temp, 0) AS Temp,
            Conditions AS WeatherCondition,
            '' AS Icon
        FROM WeatherData2
        WHERE LOCNO = ?
          AND CAST(CreatedOn AS DATE) = CAST(GETDATE() AS DATE)
        ORDER BY CreatedOn
    """, (locno,))
    rows = cursor.fetchall()
    data = [{"day": row.Day, "temp": row.Temp, "condition": row.WeatherCondition, "icon": row.Icon} for row in rows]
    conn.close()
    return jsonify(data)

def save_weather_data():
    try:
        print(f"\n⏳ Updating weather at {datetime.now()}")
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT DISTINCT State, LOCNO, PlantNo, Latitude, Longitude 
            FROM [dbo].[WEC_All_Data_2] 
            WHERE Latitude IS NOT NULL AND Longitude IS NOT NULL
        """)
        records = cursor.fetchall()

        for record in records:
            state, locno, plantno, lat, lon = record
            try:
                data = get_weather_data(lat, lon)
                for day_data in data['days']:
                    forecast_date = datetime.strptime(day_data['datetime'], '%Y-%m-%d')
                    insert_data = (
                        state, locno, plantno, lat, lon,
                        day_data.get("windspeed", 0.0),
                        day_data.get("windgust", 0.0),
                        convert_wind_direction(day_data.get("winddir", 0)),
                        day_data.get("conditions", "Unknown"),
                        day_data.get("temp", 0.0),
                        day_data.get("tempmin", 0.0),
                        day_data.get("tempmax", 0.0),
                        day_data.get("humidity", 0.0),
                        day_data.get("precip", 0.0),
                        datetime.now(),
                        forecast_date
                    )
                    cursor.execute("""
                        INSERT INTO [dbo].[WeatherData2] (
                            State, LOCNO, PlantNo, Latitude, Longitude, WindSpeed, WindGust,
                            WindDir, Conditions, Temp, Tempmin, Tempmax, Humidity, Precip, 
                            Createdon, ForecastDate
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, insert_data)
            except Exception as inner_e:
                print(f"[Error] Skipping {locno}: {inner_e}")
                continue

        print("✅ Weather update completed.")
    except Exception as e:
        print(f"❌ Error in save_weather_data: {e}")
    finally:
        conn.close()

@app.route("/view_data", methods=["GET"])
def view_data():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM [dbo].[WeatherData2]
            ORDER BY Createdon ASC
        """)
        records = [dict(zip([column[0] for column in cursor.description], row)) for row in cursor.fetchall()]
        return render_template("view_data.html", weather_data=records)
    except Exception as e:
        return f"<h2>Error loading weather data: {e}</h2>"
    finally:
        conn.close()

# Schedule job every 3 hours
scheduler = BackgroundScheduler()
scheduler.add_job(save_weather_data)
scheduler.start()

if __name__ == "__main__":
    app.run(debug=True)