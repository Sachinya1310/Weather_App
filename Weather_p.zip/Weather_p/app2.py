from flask import Flask, render_template, request, jsonify, redirect, url_for, flash # type: ignore
from apscheduler.schedulers.background import BackgroundScheduler # type: ignore
import pyodbc # type: ignore
import requests # type: ignore
import os
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed

app = Flask(__name__)
app.secret_key = "secret"

# Configuration
VC_API_KEYS = ['77EEYBH9HP5EFD3QJ44M7DX39']  # Changed to list with single key
CURRENT_API_KEY_INDEX = 0
DB_SERVER = '172.18.25.38'
DB_USER = 'sa'
DB_PASSWORD = 'wwilscada@4444'
DB_NAME = 'Weatherforecast'
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Thread pool for parallel API requests
THREAD_POOL = ThreadPoolExecutor(max_workers=10)  # Adjust based on your API rate limits

def get_db_connection():
    conn = pyodbc.connect(
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={DB_SERVER};DATABASE={DB_NAME};UID={DB_USER};PWD={DB_PASSWORD}"
    )
    conn.autocommit = True
    return conn

def convert_wind_direction(degrees):
    try:
        degrees = float(degrees)
        directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
        idx = round(degrees / 45) % 8
        return directions[idx]
    except:
        return 'Unknown'

def rotate_api_key():
    global CURRENT_API_KEY_INDEX
    CURRENT_API_KEY_INDEX = (CURRENT_API_KEY_INDEX + 1) % len(VC_API_KEYS)
    print(f"⚠️ Rotating to API key index {CURRENT_API_KEY_INDEX}")

def fetch_weather_data(location):
    global CURRENT_API_KEY_INDEX
    state, locno, plantno, lat, lon = location
    
    today = datetime.now().date()
    end_date = today + timedelta(days=4)
    
    for attempt in range(len(VC_API_KEYS)):
        current_key = VC_API_KEYS[CURRENT_API_KEY_INDEX]
        url = f"https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/{lat},{lon}/{today}/{end_date}?unitGroup=metric&key={current_key}"
        
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return (location, response.json())
        except requests.exceptions.RequestException as e:
            print(f"❌ API key {CURRENT_API_KEY_INDEX} failed for {state}-{locno}: {str(e)}")
            rotate_api_key()
    
    return (location, None)

def save_weather_data():
    try:
        print(f"\n⏳ Starting weather update at {datetime.now()}")
        start_time = datetime.now()
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Fetch all locations in one query
        print("📂 Fetching all locations from database...")
        cursor.execute("""
            SELECT State, LOCNO, PlantNo, Latitude, Longitude 
            FROM [dbo].[WEC_All_Data_2] 
            WHERE Latitude IS NOT NULL AND Longitude IS NOT NULL
        """)
        locations = cursor.fetchall()
        print(f"📍 Found {len(locations)} locations to process")
        
        # Process locations in parallel
        futures = [THREAD_POOL.submit(fetch_weather_data, loc) for loc in locations]
        processed = 0
        inserted = 0
        
        # Prepare bulk insert data
        bulk_data = []
        
        for future in as_completed(futures):
            location, data = future.result()
            state, locno, plantno, lat, lon = location
            
            if not data:
                print(f"⚠️ Skipped {state}-{locno} due to API failure")
                continue
                
            processed += 1
            if processed % 10 == 0:
                print(f"⏳ Processed {processed}/{len(locations)} locations...")
            
            # Process each day in the forecast
            for day_data in data.get('days', []):
                try:
                    forecast_date = datetime.strptime(day_data['datetime'], '%Y-%m-%d').date()
                    
                    bulk_data.append((
                        state, locno, plantno, lat, lon,
                        float(day_data.get("windspeed", 0.0)),
                        float(day_data.get("windgust", 0.0)),
                        convert_wind_direction(day_data.get("winddir", 0)),
                        str(day_data.get("conditions", "Unknown")),
                        float(day_data.get("temp", 0.0)),
                        float(day_data.get("tempmin", 0.0)),
                        float(day_data.get("tempmax", 0.0)),
                        float(day_data.get("humidity", 0.0)),
                        float(day_data.get("precip", 0.0)),
                        datetime.now(),  # Createdon
                        forecast_date    # ForecastDate
                    ))
                except Exception as day_error:
                    print(f"⚠️ Error processing day data for {state}-{locno}: {day_error}")
                    continue
        
        # Bulk insert all data at once
        if bulk_data:
            print(f"💾 Preparing to insert {len(bulk_data)} records...")
            cursor.fast_executemany = True  # Enable fast executemany for pyodbc
            cursor.executemany("""
                INSERT INTO [dbo].[WeatherData2] (
                    State, LOCNO, PlantNo, Latitude, Longitude, WindSpeed, WindGust,
                    WindDir, Conditions, Temp, Tempmin, Tempmax, Humidity, Precip, 
                    Createdon, ForecastDate
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, bulk_data)
            inserted = len(bulk_data)
        
        duration = (datetime.now() - start_time).total_seconds()
        print(f"✅ Completed in {duration:.2f} seconds. Processed {processed} locations, inserted {inserted} records")
        
    except Exception as e:
        print(f"❌ Critical error in save_weather_data: {e}")
    finally:
        if 'conn' in locals():
            conn.close()

# Schedule background job - adjust timing as needed
scheduler = BackgroundScheduler()
scheduler.add_job(save_weather_data, 'interval', minutes=0.20)  # Changed from 0.20 minutes to 5 minutes (more reasonable)
scheduler.start()

# Flask routes
@app.route("/", methods=["GET"])
def home():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT State FROM [dbo].[WEC_All_Data_2] WHERE State IS NOT NULL AND State != ''")
        states = [row[0] for row in cursor.fetchall()]
        return render_template("index.html", states=states)
    except Exception as e:
        return f"<h2>Error loading states: {e}</h2>"
    finally:
        if 'conn' in locals():
            conn.close()

@app.route("/view_data", methods=["GET"])
def view_data():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'WeatherData2'")
        if cursor.fetchone()[0] == 0:
            return "<h2>WeatherData2 table not found.</h2>"

        cursor.execute("SELECT TOP 100 * FROM [dbo].[WeatherData2] ORDER BY Createdon DESC")
        records = [dict(zip([column[0] for column in cursor.description], row)) for row in cursor.fetchall()]
        return render_template("view_data.html", weather_data=records)
    except Exception as e:
        return f"<h2>Error loading weather data: {e}</h2>"
    finally:
        if 'conn' in locals():
            conn.close()
            

@app.route("/test_db")
def test_db():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT DB_NAME(), SCHEMA_NAME()")
        db_info = cursor.fetchone()

        cursor.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'WeatherData2'")
        table_exists = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM [dbo].[WeatherData2]")
        record_count = cursor.fetchone()[0]

        cursor.execute("SELECT TOP 1 * FROM [dbo].[WeatherData2]")
        sample = cursor.fetchone()

        return render_template("db_test.html", db_name=db_info[0], schema=db_info[1],
                               table_exists=table_exists, record_count=record_count, sample=sample)
    except Exception as e:
        return f"<h2>Database test failed: {str(e)}</h2>"
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == '__main__':
    app.run(debug=True)